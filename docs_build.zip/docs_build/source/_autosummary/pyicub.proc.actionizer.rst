pyicub.proc.actionizer
======================

.. automodule:: pyicub.proc.actionizer

   
   .. rubric:: Functions

   .. autosummary::
   
      main
   