﻿pyicub.actions
==============

.. automodule:: pyicub.actions

   
   .. rubric:: Classes

   .. autosummary::
   
      ActionsManager
      GazeMotion
      JointsTrajectoryCheckpoint
      LimbMotion
      PyiCubCustomCall
      TemplateParameter
      iCubActionTemplate
      iCubActionTemplateImportedJSON
      iCubFullbodyAction
      iCubFullbodyStep
   