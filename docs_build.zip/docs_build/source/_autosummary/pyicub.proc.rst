﻿pyicub.proc
===========

.. automodule:: pyicub.proc

   
.. rubric:: Modules

.. autosummary::
   :toctree:
   :recursive:

   actionizer
   fsmizer
   icubapi
