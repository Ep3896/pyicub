pyicub.core.rpc
===============

.. automodule:: pyicub.core.rpc

   
   .. rubric:: Classes

   .. autosummary::
   
      RpcClient
   