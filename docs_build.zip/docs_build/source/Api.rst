Python API Documentation
=====================================

.. toctree::

.. autosummary::
   :toctree: _autosummary
   :recursive:

   pyicub.core
   pyicub.controllers 
   pyicub.proc
   pyicub.utils
   pyicub.actions
   pyicub.requests
   pyicub.rest
   pyicub.fsm

