﻿pyicub.requests
===============

.. automodule:: pyicub.requests

   
   .. rubric:: Classes

   .. autosummary::
   
      iCubRequest
      iCubRequestsManager
   