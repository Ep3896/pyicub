﻿pyicub.utils
============

.. automodule:: pyicub.utils

   
   .. rubric:: Functions

   .. autosummary::
   
      exportJSONFile
      firstAvailablePort
      getDecoratedMethods
      getPublicMethods
      getPyiCubInfo
      importFromJSONFile
      norm
      vector_distance
   
   .. rubric:: Classes

   .. autosummary::
   
      SingletonMeta
   