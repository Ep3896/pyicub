﻿pyicub.rest
===========

.. automodule:: pyicub.rest

   
   .. rubric:: Functions

   .. autosummary::
   
      custom_serializer
      rest_service
   
   .. rubric:: Classes

   .. autosummary::
   
      FSMsManager
      GenericType
      PyiCubApp
      PyiCubRESTfulClient
      PyiCubRESTfulServer
      RESTApp
      RESTJSON
      RESTRobot
      RESTService
      RESTSubscriberFSM
      RESTTopic
      iCubFSM
      iCubRESTApp
      iCubRESTManager
      iCubRESTServer
      iCubRESTService
      iCubRESTSubscriber
   