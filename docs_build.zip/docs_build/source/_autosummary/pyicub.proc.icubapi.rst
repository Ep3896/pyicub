pyicub.proc.icubapi
===================

.. automodule:: pyicub.proc.icubapi

   