pyicub.proc.fsmizer
===================

.. automodule:: pyicub.proc.fsmizer

   
   .. rubric:: Functions

   .. autosummary::
   
      main
   