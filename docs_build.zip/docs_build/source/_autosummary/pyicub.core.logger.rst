pyicub.core.logger
==================

.. automodule:: pyicub.core.logger

   
   .. rubric:: Classes

   .. autosummary::
   
      PyicubLogger
      YarpLogger
   